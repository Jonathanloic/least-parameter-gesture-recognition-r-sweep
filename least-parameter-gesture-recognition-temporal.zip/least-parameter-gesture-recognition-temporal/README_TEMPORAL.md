# Temporal-only attention — ready to run

The complete code base plus one extra model: **`least_parameters_temporal`**, which
applies only the temporal half of the existing `channel_temporal` attention.
It has no reduction ratio, exactly like `least_parameters_eca`.

Nothing was removed or rewritten. 28 lines were added across three files; one file is new.

## Run it — same as the ECA run, just a different `--model`

```bash
python repeat_experiments.py \
    --model least_parameters_temporal \
    --protocol loso \
    --data-root /data \
    --output-dir /results/least_parameters_temporal/loso \
    --runs 20 \
    --base-seed 42 \
    --epochs 300 \
    --batch-size 128 \
    --learning-rate 0.001 \
    --num-workers 0 \
    --device cuda \
    --calibration-session S001
```

If this copy of `repeat_experiments.py` still declares `--channel-reduction-ratio` and
`--se-reduction-ratio` as required, add `--channel-reduction-ratio 16
--se-reduction-ratio 16`. The model ignores both; they only satisfy the parser.

Seeds 42-61, 15 LOSO folds each, 300 epochs, evaluation only after the last epoch —
identical to the other variants. Output layout, file names and summary formats are
unchanged: `run_01..run_20/loso/` per fold, then `20_run_summary.json` at the top.

Expected: 1,858 trainable parameters, 300 folds, roughly 8 GPU-hours.

## Optional pre-flight check

```bash
python verify_temporal_model.py
```

No dataset needed, finishes in a second. Confirms the parameter count and that the
attention module is the same class as the one inside `channel_temporal`, producing
bit-for-bit identical output on the same weights. Nothing imports this file.

## What is new

**`model_temporal.py`** — the model. It does not reimplement the attention:

```python
from model_attention import TemporalAttention1D
```

Same class object as the one in `ChannelTemporalAttention1D`, kernel size fixed at 7
exactly as `build_least_parameters_channel_temporal_model` fixes it. The block is the
baseline's apart from the attention:

```
depthwise -> pointwise -> BatchNorm -> MaxPool(2) -> ReLU -> TemporalAttention1D -> Dropout
```

The classifier head is the baseline's, untouched.

## What changed in the existing files

| File | Added | Removed |
|---|---|---|
| `train.py` | 12 lines | 0 |
| `experiments.py` | 15 lines | 0 |
| `repeat_experiments.py` | 1 line | 0 |

The name `least_parameters_temporal` had to be added to the `choices`/`MODEL_CHOICES`
tuples, otherwise argparse rejects it as an invalid `--model` value; the rest builds the
model when that name is selected. The four existing configurations are unaffected.
